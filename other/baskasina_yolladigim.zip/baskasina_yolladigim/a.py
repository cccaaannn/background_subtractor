import cv2
import numpy as np
import random as rnd


def path_creator(path, img_count,staring_string,extension):
    img_count_str = str(img_count)
    while True:
        if(len(img_count_str)<6):
            img_count_str = "0" + img_count_str
        else:
            break
    img_name = "{0}{1}{2}{3}".format(path,staring_string,img_count_str, extension)
    return img_name

def get_images(*,img_path, staring_image, img_count, random=False):
    images = []
    for i in range(img_count):
        if(random):
            image_count = rnd.randint(1,1000)
        else:
            image_count = i + staring_image

        path = path_creator(img_path, image_count, staring_string = "in",extension = ".jpg")
        img = cv2.imread(path)
        images.append(img)
    # show_images(images)
    return images









test_img_root_path = "computer_vision\\highway\\input\\"
validation_img_root_path = "computer_vision\\highway\\groundtruth\\"


# get images
images = get_images(img_path = test_img_root_path, staring_image=1, img_count=25, random=True)

# median method
medianFrame = np.median(images, axis=0).astype(dtype=np.uint8)    
medianFrame = cv2.cvtColor(medianFrame, cv2.COLOR_BGR2GRAY)

img_count = 1
while(True):
    # get paths
    img_count += 1
    test_img_path = path_creator(test_img_root_path, img_count, staring_string = "in",extension = ".jpg")
    validation_img_path = path_creator(validation_img_root_path, img_count, staring_string = "gt",extension = ".png")

    test_img = cv2.imread(test_img_path, cv2.IMREAD_GRAYSCALE)
    val_img = cv2.imread(validation_img_path, cv2.IMREAD_GRAYSCALE)

    difference = cv2.absdiff(medianFrame, test_img)
    _, thresholded_img  = cv2.threshold(difference, 40, 255, cv2.THRESH_BINARY)

    # find error
    sum_error = abs(np.sum(thresholded_img.astype("float") - val_img.astype("float")))/255

    print("img path:{0}  ->  sum_error:{1:.0f}".format(test_img_path,sum_error))

    cv2.imshow("median img", medianFrame)
    cv2.imshow("test img", test_img)
    cv2.imshow("validation img", val_img)
    cv2.imshow("difference", thresholded_img)

    cv2.waitKey(30)
    












